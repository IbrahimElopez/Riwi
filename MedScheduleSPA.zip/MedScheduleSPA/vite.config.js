import { defineConfig } from "vite";
import tailwindcss from "@tailwindcss/vite";
import { fileURLToPath, URL } from "node:url";

/**
 * Vite configuration file.
 *
 * - Registers the TailwindCSS plugin for automatic CSS generation.
 * - Defines path aliases so imports can use short names like "@/utils"
 *   instead of long relative paths like "../../../utils".
 *
 * How to use aliases in any file:
 *   import { http } from "@/api/http";
 *   import Sidebar from "@components/Sidebar";
 */
export default defineConfig({
  plugins: [tailwindcss()],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
      "@views": fileURLToPath(new URL("./src/views", import.meta.url)),
      "@components": fileURLToPath(new URL("./src/components", import.meta.url)),
      "@controllers": fileURLToPath(new URL("./src/controllers", import.meta.url)),
      "@router": fileURLToPath(new URL("./src/router", import.meta.url)),
      "@services": fileURLToPath(new URL("./src/services", import.meta.url)),
      "@assets": fileURLToPath(new URL("./src/assets", import.meta.url)),
      "@utils": fileURLToPath(new URL("./src/utils", import.meta.url)),
      "@api": fileURLToPath(new URL("./src/api", import.meta.url)),
    },
  },
});
