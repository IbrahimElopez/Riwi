/**
 * appointment.service.js — Service layer for the /appointments API resource.
 *
 * This module centralizes all HTTP calls related to appointments.
 * Controllers and views should import from here instead of calling
 * http directly, keeping API logic decoupled from UI logic.
 *
 * Usage:
 *   import { getAppointments, createAppointment } from "@services/appointment.service";
 *
 *   const all = await getAppointments();
 *   const mine = await getAppointments({ userId: 2 });
 *   await createAppointment({ specialty: "Cardiology", ... });
 */

import { http } from "@/api/http";

/**
 * Retrieves all appointments from the API.
 * @returns {Promise<Array>} List of appointment objects.
 */
export const getAppointments = () => http.get("/appointments");

/**
 * Creates a new appointment.
 * @param {Object} data - Appointment data (userId, specialty, doctor, date, startHour, endHour, reason, status).
 * @returns {Promise<Object>} The newly created appointment object.
 */
export const createAppointment = (data) => http.post("/appointments", data);

/**
 * Fully updates an existing appointment by ID.
 * @param {number} id - The appointment ID.
 * @param {Object} data - Complete appointment data.
 * @returns {Promise<Object>} The updated appointment object.
 */
export const updateAppointment = (id, data) =>
  http.put(`/appointments/${id}`, data);

/**
 * Partially updates an appointment (e.g., only the status field).
 * @param {number} id - The appointment ID.
 * @param {Object} data - Partial fields to update.
 * @returns {Promise<Object>} The patched appointment object.
 */
export const patchAppointment = (id, data) =>
  http.patch(`/appointments/${id}`, data);

/**
 * Deletes an appointment by ID.
 * @param {number} id - The appointment ID to delete.
 * @returns {Promise<void>}
 */
export const deleteAppointment = (id) => http.delete(`/appointments/${id}`);
