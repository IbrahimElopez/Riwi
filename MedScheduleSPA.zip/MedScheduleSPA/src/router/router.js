/**
 * router.js — Client-side SPA router using the History API.
 *
 * Manages navigation without full page reloads.
 * Supports route protection (authentication guard):
 *  - Unauthenticated users trying to access /home are redirected to /.
 *  - Authenticated users trying to access / are redirected to /home.
 *
 * Route table:
 *  "/"      → loginView   (public)
 *  "/home"  → homeView    (protected — requires login)
 *  <other>  → NotFoundView (404)
 *
 * How navigation works:
 *  1. Call navigateTo("/home") anywhere in the app to change the route.
 *  2. The browser's history stack is updated via history.pushState.
 *  3. router() is called to render the matching view into #app.
 *  4. The popstate event handles the browser's back/forward buttons.
 *
 * Usage:
 *   import { navigateTo, router } from "@/router/router";
 *   navigateTo("/home");
 */

import loginView from "@/views/loginView";
import homeView from "@/views/homeView";
import NotFoundView from "@/views/notFound";
import { isAuthenticated } from "@/utils";

/**
 * Route table mapping URL paths to view functions.
 * Each value is a function that returns an HTML string.
 */
const routes = {
  "/": loginView,
  "/home": homeView,
};

/**
 * Programmatically navigates to the given path.
 * Updates the browser's URL and re-renders the current view.
 * @param {string} path - The target URL path (e.g., "/home").
 */
export const navigateTo = (path) => {
  history.pushState({}, "", path);
  router();
};

/**
 * Core router function.
 * Reads the current window path, applies auth guards,
 * and renders the matching view into the #app element.
 */
export const router = () => {
  const app = document.querySelector("#app");

  let path = window.location.pathname;

  // Auth guard: redirect unauthenticated users away from protected routes
  if (path === "/home" && !isAuthenticated()) {
    path = "/";
    history.replaceState({}, "", "/");
  }

  // Auto-redirect authenticated users away from the login page
  if (path === "/" && isAuthenticated()) {
    path = "/home";
    history.replaceState({}, "", "/home");
  }

  // Resolve the view function or fall back to 404
  const view = routes[path] ?? NotFoundView;

  app.innerHTML = view();
};

// Handle browser back/forward navigation buttons
window.addEventListener("popstate", router);
