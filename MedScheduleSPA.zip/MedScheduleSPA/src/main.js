/**
 * main.js — Application entry point.
 *
 * Imports the global stylesheet and the SPA router.
 * Waits for the DOM to be fully loaded before initializing
 * the router, ensuring the #app container exists before
 * any view attempts to render into it.
 */
import "@/style.css";
import { router } from "@/router/router";

document.addEventListener("DOMContentLoaded", () => {
  router();
});
