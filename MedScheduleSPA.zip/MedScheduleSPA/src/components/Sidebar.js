/**
 * Sidebar.js — Reusable sidebar navigation component.
 *
 * Renders a vertical navigation panel that includes:
 * - App brand/title
 * - Navigation links (Home, and conditionally admin sections)
 * - A logout button that clears the session and redirects to login
 *
 * IMPORTANT: Event listeners are attached inside a setTimeout(fn, 0)
 * to ensure the HTML has been injected into the DOM before querying
 * elements. This is required because the function returns an HTML string
 * and the browser hasn't rendered it yet at the moment of the call.
 *
 * Usage:
 *   import Sidebar from "@components/Sidebar";
 *   // Embed it in a view's returned HTML template:
 *   return `<div class="flex">${Sidebar()} <main>...</main></div>`;
 */

import { removeSession } from "@/utils";
import { navigateTo } from "@/router/router";

export default function Sidebar() {
  // Delay event binding until after the HTML is rendered into the DOM
  setTimeout(() => {
    document.querySelector("#logoutBtn")?.addEventListener("click", () => {
      removeSession();   // Clear session from localStorage
      navigateTo("/");   // Redirect to login page
    });
  });

  return `
    <aside class="w-64 bg-teal-900 text-white h-screen p-5 flex flex-col">
      <div class="mb-8">
        <h2 class="text-2xl font-bold">🏥 MedSchedule</h2>
        <p class="text-teal-300 text-xs mt-1">Appointment Management</p>
      </div>

      <nav class="flex flex-col gap-3 flex-1">
        <a
          href="/home"
          class="px-3 py-2 bg-teal-700 hover:bg-teal-600 rounded-xl transition"
          data-link
        >
          📋 My Appointments
        </a>
      </nav>

      <button
        id="logoutBtn"
        class="text-left cursor-pointer text-red-300 hover:text-white hover:bg-red-500 px-3 py-2 rounded-xl transition mt-4"
      >
        🚪 Log Out
      </button>
    </aside>
  `;
}
