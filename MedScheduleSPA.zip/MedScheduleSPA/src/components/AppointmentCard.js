/**
 * AppointmentCard.js — Reusable UI component for rendering a single appointment.
 *
 * Returns an HTML string representing an appointment card.
 * The status badge changes color depending on the appointment state:
 *   - pending  → yellow
 *   - approved → green
 *   - rejected → red
 *   - cancelled → gray
 *
 * Usage:
 *   import AppointmentCard from "@components/AppointmentCard";
 *
 *   const html = AppointmentCard(appointmentObject);
 *   container.innerHTML = appointments.map(AppointmentCard).join("");
 *
 * @param {Object} appointment - Appointment data object.
 * @param {string} appointment.specialty - Medical specialty (e.g., "Cardiology").
 * @param {string} appointment.doctor - Assigned doctor name.
 * @param {string} appointment.date - Date in YYYY-MM-DD format.
 * @param {string} appointment.startHour - Start time (e.g., "09:00").
 * @param {string} appointment.endHour - End time (e.g., "09:30").
 * @param {string} appointment.reason - Reason for the appointment.
 * @param {string} appointment.status - Current status (pending | approved | rejected | cancelled).
 * @returns {string} HTML string for the card.
 */
export default function AppointmentCard(appointment) {
  const { specialty, doctor, date, startHour, endHour, reason, status } =
    appointment;

  // Map status values to TailwindCSS badge color classes
  const statusColors = {
    pending: "bg-yellow-100 text-yellow-800",
    approved: "bg-green-100 text-green-800",
    rejected: "bg-red-100 text-red-800",
    cancelled: "bg-gray-100 text-gray-600",
  };

  const badgeClass = statusColors[status] ?? "bg-slate-100 text-slate-700";

  return `
    <article class="bg-white p-4 rounded-lg shadow border border-slate-200">
      <div class="flex justify-between items-start mb-2">
        <h3 class="font-bold text-lg text-slate-800">${specialty}</h3>
        <span class="text-xs px-2 py-1 rounded-full font-semibold ${badgeClass}">
          ${status}
        </span>
      </div>

      <div class="mt-2 text-sm text-slate-600 space-y-1">
        <p><span class="font-medium">Doctor:</span> ${doctor}</p>
        <p><span class="font-medium">Date:</span> ${date}</p>
        <p><span class="font-medium">Time:</span> ${startHour} – ${endHour}</p>
        <p><span class="font-medium">Reason:</span> ${reason}</p>
      </div>
    </article>
  `;
}
