/**
 * notFound.js — 404 Not Found view.
 *
 * Rendered by the router whenever a URL path does not match
 * any registered route in the routes table.
 *
 * Displays a large 404 message and a button that navigates
 * the user back to the root ("/") using the History API.
 *
 * The "Go Home" button uses a full page redirect (window.location.href)
 * as a safe fallback to reset the router state cleanly.
 *
 * Usage:
 *   import NotFoundView from "@/views/notFound";
 *   app.innerHTML = NotFoundView();
 */

export default function NotFoundView() {
  return `
    <div class="min-h-screen flex flex-col items-center justify-center bg-slate-50 px-4 text-center">

      <span class="text-6xl mb-4">🏥</span>

      <h1 class="text-8xl font-bold text-slate-800">404</h1>

      <h2 class="text-2xl font-semibold text-slate-600 mt-4">
        Page Not Found
      </h2>

      <p class="text-slate-400 mt-2 max-w-md">
        The route you're trying to visit doesn't exist or has been moved.
        Please check the URL or go back to the home page.
      </p>

      <button
        onclick="window.location.href = '/'"
        class="mt-8 bg-teal-600 hover:bg-teal-700 text-white px-6 py-3 rounded-xl transition font-medium"
      >
        ← Go Back Home
      </button>

    </div>
  `;
}
