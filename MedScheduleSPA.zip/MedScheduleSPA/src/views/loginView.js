/**
 * loginView.js — Login page view.
 *
 * Returns an HTML string representing the login form.
 * After the HTML is injected into the DOM, calls loginController()
 * inside a setTimeout to safely bind the form's submit event.
 *
 * The form contains:
 * - An email input (name="email")
 * - A password input (name="password")
 * - A submit button
 *
 * The controller reads inputs by their "name" attributes via form.email and form.password.
 *
 * Usage:
 *   import loginView from "@/views/loginView";
 *   app.innerHTML = loginView();
 */

import { loginController } from "@/controllers/login.controller";

export default function loginView() {
  // Bind the controller after the returned HTML is rendered into the DOM
  setTimeout(() => {
    loginController();
  });

  return `
    <div class="min-h-screen flex justify-center items-center bg-gradient-to-br from-teal-50 to-slate-100">
      <div class="bg-white p-8 rounded-2xl shadow-lg w-96">

        <div class="text-center mb-6">
          <span class="text-4xl">🏥</span>
          <h1 class="text-3xl font-bold text-teal-800 mt-2">MedSchedule</h1>
          <p class="text-slate-400 text-sm mt-1">Appointment Management System</p>
        </div>

        <form id="loginForm">
          <div class="mb-4">
            <label class="block text-sm font-medium text-slate-600 mb-1">Email</label>
            <input
              type="email"
              name="email"
              placeholder="your@email.com"
              class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400"
              required
            />
          </div>

          <div class="mb-5">
            <label class="block text-sm font-medium text-slate-600 mb-1">Password</label>
            <input
              type="password"
              name="password"
              placeholder="••••••••"
              class="border border-slate-300 w-full p-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400"
              required
            />
          </div>

          <button
            type="submit"
            class="bg-teal-600 hover:bg-teal-700 text-white w-full py-2.5 rounded-lg font-semibold transition"
          >
            Sign In
          </button>
        </form>

        <p class="text-xs text-slate-400 text-center mt-5">
          Demo: admin@medschedule.com / Admin123
        </p>

      </div>
    </div>
  `;
}
