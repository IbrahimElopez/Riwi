/**
 * homeView.js — Main dashboard view (protected route).
 *
 * Renders different content based on the current user's role:
 *   - admin: Shows an admin panel banner with management options.
 *   - user:  Shows a user panel banner with a "New Appointment" button placeholder.
 *
 * Both roles see the appointments list section below the banner.
 * The actual appointment data is fetched and rendered by homeController().
 *
 * The #appointmentsContainer div is the injection target for AppointmentCard components.
 * homeController() is called inside a setTimeout so the container exists in the DOM first.
 *
 * Structure:
 *   <div class="flex">
 *     <Sidebar />                        ← always visible
 *     <main>
 *       <header />                       ← welcome + role badge
 *       <section role-banner />          ← admin or user panel
 *       <section appointments-list>
 *         <div id="appointmentsContainer" />   ← filled by homeController
 *       </section>
 *     </main>
 *   </div>
 *
 * Usage:
 *   import homeView from "@/views/homeView";
 *   app.innerHTML = homeView();
 */

import Sidebar from "@/components/Sidebar";
import { getSession } from "@/utils";
import { homeController } from "@/controllers/home.controller";

export default function homeView() {
  const user = getSession();

  // Trigger the controller after the DOM renders
  setTimeout(() => {
    homeController();
  });

  return `
    <div class="flex min-h-screen">

      ${Sidebar()}

      <main class="flex-1 p-6 bg-slate-50">

        <!-- Welcome header -->
        <div class="mb-6">
          <h1 class="text-3xl font-bold text-slate-800">
            Welcome, ${user?.name} 👋
          </h1>
          <span class="inline-block mt-1 px-3 py-0.5 text-xs font-semibold rounded-full
            ${user?.role === "admin" ? "bg-purple-100 text-purple-700" : "bg-teal-100 text-teal-700"}">
            ${user?.role === "admin" ? "Administrator" : "Patient"}
          </span>
        </div>

        <!-- Role-specific action panel -->
        ${
          user?.role === "admin"
            ? `
          <section class="bg-purple-50 border border-purple-200 p-5 rounded-xl shadow-sm mb-6">
            <h2 class="font-bold text-xl text-purple-800 mb-1">Admin Panel</h2>
            <p class="text-purple-600 text-sm">You can view and manage all appointments in the system.</p>
            <button class="mt-3 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm transition">
              Manage Appointments
            </button>
          </section>
            `
            : `
          <section class="bg-teal-50 border border-teal-200 p-5 rounded-xl shadow-sm mb-6">
            <h2 class="font-bold text-xl text-teal-800 mb-1">Patient Panel</h2>
            <p class="text-teal-600 text-sm">Here you can see and manage your personal appointments.</p>
            <button class="mt-3 bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-lg text-sm transition">
              + New Appointment
            </button>
          </section>
            `
        }

        <!-- Appointments list section -->
        <section class="bg-white p-5 rounded-xl shadow-sm">
          <div class="flex justify-between items-center mb-4">
            <h2 class="font-bold text-xl text-slate-800">Appointments</h2>
            <span class="text-sm text-slate-400">
              ${user?.role === "admin" ? "Showing all appointments" : "Showing your appointments only"}
            </span>
          </div>

          <!-- This container is populated dynamically by homeController -->
          <div
            id="appointmentsContainer"
            class="grid gap-4 md:grid-cols-2"
          >
            <div class="w-full text-center py-8 col-span-2">
              <p class="text-slate-400">Loading appointments...</p>
            </div>
          </div>
        </section>

      </main>
    </div>
  `;
}
