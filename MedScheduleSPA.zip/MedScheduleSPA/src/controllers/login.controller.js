/**
 * login.controller.js — Controller for the login view.
 *
 * Responsibilities:
 * - Listens for the login form's submit event.
 * - Reads and trims the email and password inputs.
 * - Queries the json-server /users endpoint to validate credentials.
 * - On success: saves the session to localStorage and navigates to /home.
 * - On failure: shows an error message to the user.
 *
 * This controller is called from loginView.js inside a setTimeout
 * to ensure the form element exists in the DOM before attaching events.
 *
 * Usage:
 *   import { loginController } from "@/controllers/login.controller";
 *   // Called inside loginView after the HTML is rendered
 *   setTimeout(() => loginController());
 */

import { saveSession } from "@/utils";
import { navigateTo } from "@/router/router";
import { http } from "@/api/http";

export const loginController = () => {
  const form = document.querySelector("#loginForm");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = form.email.value.trim();
    const password = form.password.value.trim();

    // Show loading state on the submit button
    const btn = form.querySelector("button[type='submit']");
    btn.disabled = true;
    btn.textContent = "Logging in...";

    try {
      // Query json-server with email + password as filters
      const users = await http.get(`/users?email=${email}&password=${password}`);

      if (!users.length) {
        // No matching user found — credentials are invalid
        showError("Invalid email or password. Please try again.");
        return;
      }

      // Persist only safe, non-sensitive fields in the session
      saveSession({
        id: users[0].id,
        name: users[0].name,
        role: users[0].role,
      });

      navigateTo("/home");
    } catch (error) {
      console.error(error);
      showError("Could not connect to the API. Make sure json-server is running on port 3000.");
    } finally {
      btn.disabled = false;
      btn.textContent = "Sign In";
    }
  });
};

/**
 * Displays an error message below the form.
 * Creates or updates an element with id "loginError".
 * @param {string} message - The error text to display.
 */
function showError(message) {
  let errorEl = document.querySelector("#loginError");
  if (!errorEl) {
    errorEl = document.createElement("p");
    errorEl.id = "loginError";
    errorEl.className = "text-red-500 text-sm mt-3 text-center";
    document.querySelector("#loginForm").appendChild(errorEl);
  }
  errorEl.textContent = message;
}
