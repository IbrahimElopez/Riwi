/**
 * home.controller.js — Controller for the home view.
 *
 * Responsibilities:
 * - Fetches all appointments from the json-server API.
 * - Filters results based on the current user's role:
 *     - admin → sees ALL appointments from every user.
 *     - user  → sees ONLY their own appointments (matched by userId).
 * - Renders appointment cards into the #appointmentsContainer element.
 * - Shows a friendly empty state message if no appointments are found.
 *
 * This controller is called from homeView.js inside a setTimeout to
 * ensure the DOM container exists before trying to inject HTML into it.
 *
 * Usage:
 *   import { homeController } from "@/controllers/home.controller";
 *   setTimeout(() => homeController());
 */

import AppointmentCard from "@components/AppointmentCard";
import { getAppointments } from "@services/appointment.service";
import { getSession } from "@/utils";

export const homeController = async () => {
  const container = document.querySelector("#appointmentsContainer");

  // Get the logged-in user from session storage
  const user = getSession();

  try {
    // Fetch all appointments from the API
    const appointments = await getAppointments();

    // Apply role-based filtering:
    // Admins see everything; regular users only see their own appointments
    const filtered =
      user.role === "admin"
        ? appointments
        : appointments.filter((a) => a.userId === user.id);

    // Render cards or display an empty state
    container.innerHTML = filtered.length
      ? filtered.map((a) => AppointmentCard(a)).join("")
      : `
        <div class="w-full text-center py-10 col-span-2">
          <p class="text-slate-400 text-lg">No appointments found.</p>
          <p class="text-slate-400 text-sm mt-1">
            ${user.role === "user" ? "You haven't made any appointments yet." : "There are no appointments in the system."}
          </p>
        </div>
      `;
  } catch (error) {
    console.error("Failed to load appointments:", error);
    container.innerHTML = `
      <div class="w-full text-center py-10 col-span-2">
        <p class="text-red-400 text-lg">Error loading appointments.</p>
        <p class="text-slate-400 text-sm mt-1">Make sure the json-server is running on port 3000.</p>
      </div>
    `;
  }
};
