/**
 * utils.js — Reusable session utility functions.
 *
 * All session data is persisted in localStorage under the key "user".
 * The stored value is a JSON string containing id, name, and role.
 *
 * These functions act as a simple auth layer throughout the app:
 * - Used by the router to protect private routes.
 * - Used by views to personalize content based on the logged-in user.
 * - Used by controllers to filter data by role.
 */

/**
 * Saves a user object to localStorage.
 * Called after a successful login.
 * @param {{ id: number, name: string, role: string }} user
 */
export const saveSession = (user) => {
  localStorage.setItem("user", JSON.stringify(user));
};

/**
 * Retrieves the current session from localStorage.
 * Returns null if no session exists.
 * @returns {{ id: number, name: string, role: string } | null}
 */
export const getSession = () => {
  return JSON.parse(localStorage.getItem("user"));
};

/**
 * Removes the session from localStorage.
 * Called on logout to fully clear user data.
 */
export const removeSession = () => {
  localStorage.removeItem("user");
};

/**
 * Checks whether a user is currently logged in.
 * @returns {boolean} true if a session exists, false otherwise.
 */
export const isAuthenticated = () => {
  return !!getSession();
};

/**
 * Checks whether the current user has the "admin" role.
 * @returns {boolean} true if user is admin, false otherwise.
 */
export const isAdmin = () => {
  return getSession()?.role === "admin";
};
