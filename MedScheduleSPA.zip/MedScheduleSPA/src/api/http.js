/**
 * http.js — Generic HTTP client for the json-server API.
 *
 * Provides a thin wrapper around the native Fetch API.
 * All requests automatically set Content-Type to application/json
 * and throw an error on non-2xx HTTP responses.
 *
 * Base URL is set to the local json-server instance on port 3000.
 *
 * Usage example:
 *   import { http } from "@/api/http";
 *
 *   // GET all appointments
 *   const appointments = await http.get("/appointments");
 *
 *   // POST a new appointment
 *   const created = await http.post("/appointments", { specialty: "Neurology", ... });
 *
 *   // PUT (full update) an appointment
 *   await http.put("/appointments/1", { ...updatedData });
 *
 *   // PATCH (partial update) an appointment's status
 *   await http.patch("/appointments/1", { status: "approved" });
 *
 *   // DELETE an appointment
 *   await http.delete("/appointments/1");
 */

const API_URL = "http://localhost:3000";

/**
 * Internal function that performs the actual fetch request.
 * @param {string} endpoint - The API path, e.g. "/appointments"
 * @param {RequestInit} options - Fetch options (method, body, headers override, etc.)
 * @returns {Promise<any>} Parsed JSON response
 */
const request = async (endpoint, options = {}) => {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      headers: {
        "Content-Type": "application/json",
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`HTTP Error ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error(error);
    throw error;
  }
};

/**
 * Exported HTTP methods.
 * Each method maps to the corresponding HTTP verb.
 */
export const http = {
  /** Fetches data from the given endpoint. */
  get: (endpoint) => request(endpoint),

  /** Sends a new resource to the given endpoint. */
  post: (endpoint, data) =>
    request(endpoint, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  /** Fully replaces a resource at the given endpoint. */
  put: (endpoint, data) =>
    request(endpoint, {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  /** Partially updates a resource at the given endpoint. */
  patch: (endpoint, data) =>
    request(endpoint, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

  /** Deletes a resource at the given endpoint. */
  delete: (endpoint) =>
    request(endpoint, {
      method: "DELETE",
    }),
};
